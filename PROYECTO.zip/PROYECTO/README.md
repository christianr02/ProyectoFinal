# Tech News HTML
![](./screenshot.png)

# Recomendations
* Minimize the size of Images
* put a favicon

# Resources
* [Pexels.com](https://www.pexels.com/)
* [HeroPatterns.com](https://www.heropatterns.com/). Death Start is choosen in this project